

Name: Kevin Haro 
Class: CS482 

This file is serving as an instruction information to run this project of phase 2 for 
databases. 

What is included in this file is my Hospital_Schema: 
insert.dbl # Data to be inserted into the database
create.dbl # creation of the tables for the database
phase2.py  # My python file to connect and run mySQL queries 

In my phase2.py, you don't need to edit any of the python code so there's no hard code needed
to be changed. It'll prompt you the information needed to connect and run mySQL queries

HEADS-UP: 
	If you're running this script on MacOS, you need to type python3 and not like the professor 
	sample to run it with just python <file_name.py> 6 beta
	In MacOS, you need to run it as python3 <file_name.py> 6 beta

Example: 
	For query 6,
	> python3 phase2.py 6 2022-03-22
	After entering this it'll prompt you with a series of questions to connect 
	to mySQL workbench 
	It'll ask for the name of host, database name, user_name, and password.
	and output of the query will happen 


