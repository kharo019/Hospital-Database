#
# 
#
#

import mysql.connector
from mysql.connector import Error

import sys

from typing import List

# in the read file include when running on the terminal if they are running it on the mac 
# it must be python3 fileName.py 1 arguments

RED = '\033[91m'
END = '\033[0m'

one_param_message = f"""
                        {RED}Wrong argument count, please pass only one argument,
                        The question number {END}
                    """

two_param_message = f"""
                        {RED}Wrong argument count please pass two arguments,
                        the question number and the query parameters {END}
                    """
three_param_message = f"""
                        {RED}Wrong argument count please pass three arguments,
                        the question number and the query parameters {END}
                    """

# try: # this works well reference 
# 	connection = mysql.connector.connect(
#     	host="localhost",
#     	database="Hospital_Schema",
#     	user="root",
#     	password="" )
# 	# conn = pyodbc.connect(conn_str)
# 	cursor = connection.cursor()
# 	cursor.execute("SELECT * FROM Physician")
# 	for row in cursor:
#     		print(row)
# except Error as e:
# 	print("Error")


# connectioToDatabase takes in the parameters required to connect to a database 
# specifically in mySQL workbench 
# It'll prompt the user from main and pass it to this function 
# it'll either prompt a success message or error message 
def connectionToDatabase(hostName, databaseName,userName,passwordName):
	try:
		connection = mysql.connector.connect(
    		host = hostName,
    		database = databaseName,
    		user = userName,
    		password = passwordName
		)
		print("Connection established with database")

	except Error as err:
		print("Connection to database failed. Error: %s" % err)
	
	return connection


def execution(connection, input_query:str, arguments:list) -> List[tuple]:

	ouput = [("NO RESULT",)]
	cursor = connection.cursor()

	try: 
		cursor.execute(input_query, arguments)
		try: 
			output = cursor.fetchall()
		except mysql.connector.InterfaceError:
			print("MySQl Connect")

		connection.commit() # Remember to add this bad boy back in the future 
		cursor.close()

	except Error as e:
		print(e)
		print(cursor.statement)
	if type(output) == list and len(output) == 0:
		output = [("NO RESULT",)]

	return output


def printResults(output):
	for i in output:
		print(i)
	print("\n")

# To answer the query questions, a function was created for each problem 
# each function will take in the connection to the database access and return 
# the solution data of the query problem 



# Find information about all appointments with physicians affiliated with a given department name. 
# Show the detailed information of each patient along with the detailed information of the physician with whom they have met and the appointment ID. 
# Sample output: As an example, following is the output for the given department name "Surgery":
# patientID: 1, patient_ssn: 100001, patient_name: John Smith, patient_address: 12 Foo Drive, patient_dob: 1980-01-01, 
# patient_phone: 575-123-1234, patient_insuranceNumber: 123454, patient_primaryPhysID: 1, physicianID: 1, physician_name: John Doe, 
# physician_position: Surgeon, physician_ssn: 11111111, appointmentID: 1

def question8(connection, args: List):
	
	assert len(args) == 1, two_param_message

	
	input_query = """

		select P.patientID, P.ssn as patient_ssn, P.name as patient_name, P.address as patient_address,
			P.dob as patient_dob, P.phone as patient_phone, P.insuranceNumber as patient_insuranceNumber,
        	P.primaryPhysID as patient_primaryPhysID, PH.physicianID, PH.name as physician_name, 
			PH.position as physician_position, 
        	PH.ssn as physician_ssn, A.appID as appointmentID 
		from patient P inner join physician PH on P.primaryPhysID = PH.physicianID 
			inner join Appointment A on PH.physicianID = A.physicianID 
		where PH.position = %s;
			
		"""

	results = execution(connection,input_query, args)

	printResults(results)
	
	

# Find all patients that have stayed together in a "Double" room at a given date. For each room ID, show each patient's name and their start and end date of stay.
# Sample output: As an example, following is the output for the given date 2022-01-15 
# (In this example, Dr. Nagarkar was lucky enough to stay with Bruno Mars in the same room).
# Room ID: 1
# Patient: John Doe, Stay Start Date: 2022-01-10, Stay End Date: 2022-01-20
# Patient: Jane Doe, Stay Start Date: 2022-01-14, Stay End Date: 2022-01-16
# Room ID: 2
# Patient: Parth Nagarkar, Stay Start Date: 2022-01-12, Stay End Date: 2022-01-17
# Patient: Bruno Mars, Stay Start Date: 2022-01-15, Stay End Date: 2022-01-15
def question7(connection, args: List):
	
	print("question 7")

	assert len(args) ==1, two_param_message

	input_query = """
	select P.name, S.startDate, S.endDate 
	from Patient P inner join Stay S on P.patientID = S.patientID inner join Room R on S.roomID = R.roomID 
	where R.roomType = "Double" and (%s between S.startDate and S.endDate);
	"""

	results = execution(connection,input_query,args)

	printResults(results)






#Find nurses who have been on call at a given date. Show the detailed information of each nurse and their on call start date and end date.
# Sample output: As an example, following is the output for the given date 2022-01-15:
# nurseID: 1, name: Jane Doe, position: Head Nurse, ssn:3333333, on_call_start_date: 2022-01-01, on_call_end_date: 2022-02-01
def question6(connection, args: List):
	print("question 6")

	assert len(args) == 1, two_param_message

	input_query = """
        select N.nurseID, N.name, N.position, N.ssn, OC.startDate as on_call_start_date, OC.endDate as on_call_end_date
		from nurse N inner join onCall OC on OC.nurseID = N.nurseID
		where %s between OC.startDate and OC.endDate;
    """
	results = execution(connection,input_query,args)

	printResults(results)



# Find information about a prescribed medication name. Show the patients name, physicians names, and the prescribed dates. 
# Sample output: As an example, following is the output for the given medication name "Med A":
# patient_name: John Smith, physician_name: John Doe, prescribed_date: 2022-01-15
def question5(connection, args: List):
	print("question 5")

	# NEEDS FIXING FOR MEDICATION PART SO SEE IF WE CAN ACCEPT MORE THAN TWO PARAMETERS!!!!
	assert len(args) == 1, two_param_message
	
	input_query = """
        select PA.name as patient_name, PH.name as physician_name, PR.prescribedDate as prescribed_date
		from Medication M inner join Prescribes PR on M.medID = PR.medicationID 
				inner join Patient PA on PA.patientID = PR.patientID 
				inner join physician PH on PH.physicianID = PR.physicianID
		where M.name = %s;
    	"""
	
	results = execution(connection,input_query, args)

	printResults(results)


# Find the patients that their primary physician is the head of a given department name. Show the detailed information of each patient. 
# Sample output: As an example, following is the output for the given department "Surgery":
# patientID: 1, ssn: 100001, name: John Smith, address: 12 Foo Drive, dob: 1980-01-01, phone: 575-123-1234, insuranceNumber: 123454, primaryPhysID: 1
def question4(connection, args: List):
	print("question 4")

	assert len(args) == 1, two_param_message

	input_query = """""
		select P.patientID, P.ssn, P.name, P.address, P.dob, P.phone, P.insuranceNumber, P.primaryPhysID 
		from patient P inner join Physician PH on P.primaryPhysID = PH.physicianID inner join department D on PH.physicianID = D.headID
		where PH.position = %s;
	"""

	results = execution (connection,input_query, args)

	printResults(results)



# Find the patients that have undergone a procedure with a cost larger than a given cost. Show the detailed information of each patient. 
# Sample output: As an example, following is the output for the given cost 500.00:
# patientID: 1, ssn: 100001, name: John Smith, address: 12 Foo Drive, dob: 1980-01-01, phone: 575-123-1234, insuranceNumber: 123454, primaryPhysID: 1
def question3(connection, args: List):
	print("question3")

	input_query = """""
		select P.patientID, P.ssn, P.name, P.address, P.dob, P.phone, P.insuranceNumber, P.primaryPhysID 
		from patient P inner join `procedure` PR on PR.name = P.name
		where PR.cost > %s;
	"""

	results = execution(connection,input_query, args)

	printResults(results)




# Find appointments where a patient met with a physician other than their primary physician.
# Show patient name, physician name, nurse name, start and end datetime of appointment, and the name of the patient's primary physician.
# Sample output: As an example, following is the output:
# patient_name: John Smith, physician_name: John Doe, nurse_name: Jane Doe, start_datetime: 2021-12-05 14:00, end_datetime: 2021-12-05 15:00, 
# primary_physician: John Doe
def question2(connection,args: List):

	assert len(args) == 0, one_param_message
	
	print("question 2 ")

	input_query = """
        select P.name as patient_name, PH.name as physician_name, N.name as nurse_name,
				A.startDateTime, A.endDateTime, physician.name as primary_physician
		from Appointment A inner join Patient P on A.patientID = P.patientID
				inner join Physician PH on A.physicianID = PH.physicianID 
   				inner join Nurse N on A.nurseID = N.nurseID inner join Physician on physician.physicianID = P.primaryPhysID
		where P.primaryPhysID != PH.physicianID;

    	"""
	results = execution(connection,input_query,())
	printResults(results)


# Find physicians that have performed a given procedure name. Show the detailed information of each physician. 
# Sample output: As an example, following is the output for the given procedure name "Proc A":
# physicianID: 1, name: John Doe, position: Surgeon, ssn: 11111111
def question1(connection, arguments: List):
	
	assert len(arguments) == 1, two_param_message
	print("question1")

	input_query = """
        select P.physicianID, P.name, P.position, P.ssn
		from physician P inner join department D on D.headID = P.physicianID
		where D.name = %s;
    	"""


	results = execution(connection,input_query, arguments)
	printResults(results)


def retrieveAllData(connection, arguments: List):
	assert len(arguments) == 1, two_param_message
	print("retrieveAllData")

	input_query = """
		select * from %s;
	"""

	results = execution(connection,input_query, arguments)
	printResults(results)


	# -5: Query 1 is wrong and is not the answer to question 1.
	# -5: Query 4 is wrong and not outputting any results.
	# -5: Query 8 is wrong and not outputting any results.


# When python proj.py 1 <procedure_name> is ran
# the first argument will be the questionNumber args that'll recognize what number
# of question it is expecting
questionNum = {
	"1": question1,
	"2": question2,
	"3": question3,
	"4": question4,
	"5": question5,
	"6": question6,
	"7": question7,
	"8": question8,
	"retrieveAllData": retrieveAllData,
}


# main function to call other functions to connect to databases 
# 
def main():

	print("Enter the name of your host:")

	hostName = input ("By default, the host is 'localhost': ")
	databaseName = input("Enter the database name: ")
	userName = input("Enter the user name: ")
	passwordName = input("Enter your password: ")

	connection = connectionToDatabase(hostName,databaseName,userName,passwordName)

	print("Connection to database is established")

	queryNumber = sys.argv[1]
	arguments = sys.argv[2:]

	print("Solution to the query number " + queryNumber)

	try: 
		questionNum[queryNumber](connection, arguments)
	except:
		print("Unidenitified question number " + queryNumber)
		print("Or other unknown error occurred")


# Without this line of code, main will never be run and will just compile the script
if __name__ == "__main__":
    main()



